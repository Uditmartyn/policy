'use strict';
require('dotenv').config() ;
const mysql = require('mysql2');

const config = {
  connectionLimit : 500,
  multipleStatements: true,
  connectTimeout: 1000000,
  host     : process.env.DB_SERVER ||  'localhost',
  user     : process.env.DB_USER || 'policicue',
  password : process.env.DB_PASSWORD || 'Polic!@cu3#',
  database : process.env.DB_NAME || 'policicue',
  port     : '3306'
};

const configLocal = {
  connectionLimit : 500,
  multipleStatements: true,
  connectTimeout: 1000000,
  host     : 'localhost',
  user     : 'root',
  password :  '',
  database : 'policicue',
  port     : '3306'
};

// const pool =  mysql.createPool(configLocal);

// Ping database to check for common exception errors.
// pool.getConnection((err, connection) => {
//   if (err) {
//       if (err.code === 'PROTOCOL_CONNECTION_LOST') {
//           console.error('Database connection was closed.')
//       }
//       if (err.code === 'ER_CON_COUNT_ERROR') {
//           console.error('Database has too many connections.')
//       }
//       if (err.code === 'ECONNREFUSED') {
//           console.error('Database connection was refused.')
//       }
//   }
  
//   if (connection) {
//     console.log('Database Connection established ***************');
//     connection.release();
//   }   
//    return
// });

// module.exports = pool.promise();



function createPool() {
  try {
    const pool = mysql.createPool(config);
    const promisePool = pool.promise();
    return promisePool;
  } catch (error) {
    return console.log(`Could not connect - ${error}`);
  }
}

const pool = createPool();

module.exports = {
  getConnection: async () => pool.getConnection(),
  execute: (...params) => pool.execute(...params)
};