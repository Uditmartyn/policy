const nodemailer = require('nodemailer');
const path = require('path');
const fs = require('fs');

module.exports.mailfunctionWithAttachment = async (from, to, subject, message,mailData) => {
  try {      
    let transporter = nodemailer.createTransport({     
      service: "gmail",		
      auth: {
        user: process.env.SENDER_EMAIL,
        pass: process.env.SENDER_PASSWORD
      },
      secure:true,
      secured:true,
      requireTLS:true,
      tls: {
        rejectUnauthorized: false
      } ,
      pool: true,
      maxConnections :1000,
      maxMessages :1000
      
    });
    
    const mailOptions = {
        from: from, // sender address
        to:  to, // list of receiver      
        bcc: 'nitin.shegal@mobileprogramming.com,rishav.tomer@mobileprogramming.com',
        subject: subject, // Subject line
        html: message, // plain text body
        attachments: [
          {  
            filename: mailData.filename,				
            path: mailData.path				
          }
      ]
    };
   
    await  transporter.sendMail(mailOptions);    
    return { status: 1, message: "mail send" }
  } catch (error) {    
      return { status: 0, message: "mail not send" };
      
  }
}



module.exports.mailfunction = async (from, to, subject, message) => {
  try {   

    let transporter = nodemailer.createTransport({
      service: "gmail",		
      auth: {
        user: process.env.SENDER_EMAIL,
        pass: process.env.SENDER_PASSWORD
      },
      secure:true,
      secured:true,
      requireTLS:true,
      tls: {
        rejectUnauthorized: false
      } ,
      pool: true,
      maxConnections :1000,
      maxMessages :1000
      
    });

    const mailOptions = {
        from: from, // sender address
        to:  to, // list of receiver      
        bcc: 'nitin.shegal@mobileprogramming.com',
        subject: subject, // Subject line
        html: message // plain text body
    };
     
    await  transporter.sendMail(mailOptions);   
    transporter.close();
    return { status: 1, message: "mail send" }
  } catch (error) {     
      return { status: 0, message: "mail not send" };
      
  }
}
