function test(req) {
    console.log(req.body) ;
    console.log("i am here") ;
}
module.exports = test ;