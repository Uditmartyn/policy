'user strict';

const  connection  = require('../../../db.js');
const  ERROR_MSG =   require('../message.json');

module.exports.getsalaryRange = async (req, res, next) => {
    try{
        var conn = await connection.getConnection();     
        const [rows] = await conn.execute(`SELECT * from salaryranges`);
        if (rows.length == 0) {
            conn.release();
            return {
                message: ERROR_MSG.NO_RECORD,
                status:0
            };
        } else {           
            conn.release();
            return {  
                message: ERROR_MSG.SUCCESS,
                status: 1,
                data:rows         
            };           
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}
module.exports.getInsuranceCompanies = async (req, res, next) => {
    try{
        var conn = await connection.getConnection();     
        const [rows] = await conn.execute(`SELECT * from life_insurance_companies`);
        if (rows.length == 0) {
            conn.release();
            return {
                message: ERROR_MSG.NO_RECORD,
                status:0
            };
        } else {           
            conn.release();
            return {  
                message: ERROR_MSG.SUCCESS,
                status: 1,
                data:rows         
            };           
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}
module.exports.InsertData = async (tableName, body) => {    
    try{
        var conn = await connection.getConnection();     
        const query = "INSERT into  "+tableName+"  (" + Object.keys(body).map(key => `${key}`).join(", ") + ") values ("+Object.keys(body).map(key => `?`).join(", ")+")";   
        const [rows] = await conn.execute(query,Object.values(body)); 
        if (rows.length == 0) {
            conn.release();
            return {
                message: ERROR_MSG.NO_RECORD,
                status:0
            };
        } else {           
            conn.release();
            return {  
                message: ERROR_MSG.SUCCESS,
                status: 1,
                data:rows         
            };           
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }

}
module.exports.getCustomerDetails = async (tableName) => {
    try{
        var conn = await connection.getConnection();     
        const [rows] = await conn.execute(`SELECT * from ${tableName}`);
        if (rows.length == 0) {
            conn.release();
            return {
                message: ERROR_MSG.NO_RECORD,
                status:0
            };
        } else {           
            conn.release();
            return {  
                message: ERROR_MSG.SUCCESS,
                status: 1,
                data:rows         
            };           
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}
module.exports.checkUserExists = async (tableName, phoneNumber) => {
    try{
        var conn = await connection.getConnection();     
        const [rows] = await conn.execute(`SELECT * FROM ${tableName} WHERE mobileNo = ${phoneNumber}`);
        if (rows.length == 0) {
            conn.release();
            return {
                message: ERROR_MSG.NO_RECORD,
                status:0
            };
        } else {           
            conn.release();
            return {  
                message: ERROR_MSG.SUCCESS,
                status: 1,
                data:rows         
            };           
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}
module.exports.updateData = async (body, tableName, portfolioId ) => {
    try{
        var conn = await connection.getConnection();     
        const query = "UPDATE "+tableName+" SET " + Object.keys(body).map(key => `${key} = ?`).join(", ") + " WHERE id = ?";    
        const parameters = [...Object.values(body), portfolioId];   
        const [rows] = await conn.execute(query, parameters);  

        if (rows.length == 0) {
            conn.release();
            return {
                message: ERROR_MSG.NO_RECORD,
                status:0
            };
        } else {           
            conn.release();
            return {  
                message: ERROR_MSG.SUCCESS,
                status: 1,
                data:rows         
            };           
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}

