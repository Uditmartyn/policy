'user strict';

const  connection  = require('../../../db.js');
const  ERROR_MSG =   require('../message.json');

module.exports.getCountriesList = async (req, res, next) => {
    try{
        var conn = await connection.getConnection();     
        const [rows] = await conn.execute(`SELECT * from travelcountrieslist`);
        if (rows.length == 0) {
            conn.release();
            return {
                message: ERROR_MSG.NO_RECORD,
                status:0
            };
        } else {           
            conn.release();
            return {  
                message: ERROR_MSG.SUCCESS,
                status: 1,
                data:rows         
            };           
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}


