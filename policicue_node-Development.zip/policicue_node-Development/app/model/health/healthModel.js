'user strict';

const  connection  = require('../../../db.js');
const  ERROR_MSG =   require('../message.json');

module.exports.getCityPincodes = async (req, res, next) => {
    try{
        var conn = await connection.getConnection();     
        const [rows] = await conn.execute(`SELECT * from citypincodes`);
        if (rows.length == 0) {
            conn.release();
            return {
                message: ERROR_MSG.NO_RECORD,
                status:0
            };
        } else {           
            conn.release();
            return {  
                message: ERROR_MSG.SUCCESS,
                status: 1,
                data:rows         
            };           
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}
module.exports.getHealthInsurers = async (req, res, next) => {
    try{
        var conn = await connection.getConnection();     
        const [rows] = await conn.execute(`SELECT * from insurers`);
        if (rows.length == 0) {
            conn.release();
            return {
                message: ERROR_MSG.NO_RECORD,
                status:0
            };
        } else {           
            conn.release();
            return {  
                message: ERROR_MSG.SUCCESS,
                status: 1,
                data:rows         
            };           
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}
module.exports.getCoverAmount = async (req, res, next) => {
    try{
        var conn = await connection.getConnection();     
        const [rows] = await conn.execute(`SELECT * from coveramount`);
        if (rows.length == 0) {
            conn.release();
            return {
                message: ERROR_MSG.NO_RECORD,
                status:0
            };
        } else {           
            conn.release();
            return {  
                message: ERROR_MSG.SUCCESS,
                status: 1,
                data:rows         
            };           
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}

module.exports.getExistingIllness = async (req, res, next) => {
    try{
        var conn = await connection.getConnection();     
        const [rows] = await conn.execute(`SELECT * from existingillness`);
        if (rows.length == 0) {
            conn.release();
            return {
                message: ERROR_MSG.NO_RECORD,
                status:0
            };
        } else {           
            conn.release();
            return {  
                message: ERROR_MSG.SUCCESS,
                status: 1,
                data:rows         
            };           
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}
module.exports.addCustomerDetails = async (tableName, body) => {    
    try{
        var conn = await connection.getConnection();     
        const query = "INSERT into  "+tableName+"  (" + Object.keys(body).map(key => `${key}`).join(", ") + ") values ("+Object.keys(body).map(key => `?`).join(", ")+")";   
        const [rows] = await conn.execute(query,Object.values(body)); 
        if (rows.length == 0) {
            conn.release();
            return {
                message: ERROR_MSG.NO_RECORD,
                status:0
            };
        } else {           
            conn.release();
            return {  
                message: ERROR_MSG.SUCCESS,
                status: 1,
                data:rows         
            };           
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }

}
module.exports.updateData = async (body, tableName, portfolioId ) => {
    try{
        var conn = await connection.getConnection();     
        const query = "UPDATE "+tableName+" SET " + Object.keys(body).map(key => `${key} = ?`).join(", ") + " WHERE id = ?";    
        const parameters = [...Object.values(body), portfolioId];   
        const [rows] = await conn.execute(query, parameters);  

        if (rows.length == 0) {
            conn.release();
            return {
                message: ERROR_MSG.NO_RECORD,
                status:0
            };
        } else {           
            conn.release();
            return {  
                message: ERROR_MSG.SUCCESS,
                status: 1,
                data:rows         
            };           
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}
module.exports.checkUserExists = async (tableName, phoneNumber) => {
    try{
        var conn = await connection.getConnection();     
        const [rows] = await conn.execute(`SELECT * FROM ${tableName} WHERE phoneNumber = ${phoneNumber}`);
        if (rows.length == 0) {
            conn.release();
            return {
                message: ERROR_MSG.NO_RECORD,
                status:0
            };
        } else {           
            conn.release();
            return {  
                message: ERROR_MSG.SUCCESS,
                status: 1,
                data:rows         
            };           
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}

