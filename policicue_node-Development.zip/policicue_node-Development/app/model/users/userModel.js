'user strict';

const bcrypt = require('bcryptjs');
var _ = require('underscore');
const jwt = require('jsonwebtoken');
const fs = require('fs');
const mail = require('../../middleware/mail.js');
const readXlsxFile = require("read-excel-file/node");
const path = require('path');     
const { exit, resourceUsage } = require('process');
const async = require('async');
const { isBoolean } = require('underscore');

const  connection  = require('../../../db.js');
const  commonModel = require('../commonModel')
const  templateForgot =  require('../../emailTemplate/forgotTemplate')
const  templateSignup =  require('../../emailTemplate/signupTemplate')
const  templateOtp =  require('../../emailTemplate/otpTemplate')
const  ERROR_MSG =   require('../message.json')

/** **********************************************************************
 *                  List of User login Function
 **************************************************************************/
module.exports.login = async (email, password) => {   
    try {        
        var conn = await connection.getConnection();     
        const [rows]  =  await conn.execute(`SELECT * FROM users WHERE role = ?  AND (phone = ?  OR email = ? )`,["Normal",email,email]);       
        // const [rows]  =  await conn.execute('SELECT * FROM users WHERE (email = ? AND role = ? ) OR (phone = ? AND role = ? )',[email,"Normal",email,"Normal"]);       
    //    console.log(rows)
        if (rows.length > 0) {            
            conn.release();     
            if(rows[0].IsOtpVerified == 0){
                return {
                    message: ERROR_MSG.ACC_NOT_VERIFY,
                    status: 0
                };
            }
            if(rows[0].isDeleted == 1){
                conn.release();
                return {
                    message: ERROR_MSG.ACC_DELETE,
                    status: 0
                };
            }
            if(rows[0].isBlocked == 1){
                conn.release();
                return {
                    message: ERROR_MSG.ACC_BLOCK,
                    status: 0
                };
            }
            const isEqual = await bcrypt.compare(password, rows[0].password);         
            if (!isEqual) {
                conn.release();
                return {
                    message: ERROR_MSG.LOGIN_ERROR,
                    status: 0
                };
            }
            else {               
               
                //genrate json web token
                const token = jwt.sign({
                    email: email,
                    user_id: rows[0].id,                   
                    phone :rows[0].phone                   
                }, process.env.JWT_KEY, {
                    expiresIn: "10d"
                });
                conn.release();
               
                rows[0].token = token 
                delete rows[0].password              
                return {  
                    message:'success',  
                    data:rows[0],     
                    status:1                    
                };
            }
        } else {
            conn.release();
            return {
                message: ERROR_MSG.LOGIN_ERROR,
                status: 0
            };
        }
       
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}

module.exports.signup = async (body) => {   
    try {
        var conn = await connection.getConnection();     
        let payloadData = body
        payloadData.fullName = 'User'
        const hashPassword = await bcrypt.hash(payloadData.password, 12);

        const [rows]  =  await conn.execute('SELECT * FROM users WHERE email = ? AND phone = ? AND role = ? ',[payloadData.email,payloadData.phone,'Normal']);      
        if (rows.length > 0) {
            conn.release();
            console.log(rows[0])
            if(rows[0].IsOtpVerified == 1){
                return {
                    message: ERROR_MSG.EMAIL_ALREADY,
                    status: 0
                };
            }

            if(rows[0].otp != payloadData.otp){
                return {
                    message: ERROR_MSG.OTP_NOT_MATCH,
                    status: 0
                };    
            } 

            const userId = rows[0].id;  
            await conn.execute('UPDATE users SET password = ?, IsOtpVerified = ?, otp = ? , isNormalSignup = ? WHERE id = ?',[ hashPassword,1,'',1,userId]);
            conn.release();     
            
            const subject = "Polici Cue - SignUp";
            const from = 'Polici Cue <testing.mobileprogramming@gmail.com>';
            const to = payloadData.email;  
            payloadData.logo = BaseURL+'/PoliciCueLogo.png'
            const message = await templateSignup.signupTemplate(payloadData)
            mail.mailfunction(from, to, subject, message);

            const token = jwt.sign({
                email: payloadData.email,
                user_id: userId,
                
            }, process.env.JWT_KEY, {
                expiresIn: "2d"
            });
            rows[0].token = token 
            delete rows[0].password      
            conn.release();
            return {  
                message:ERROR_MSG.SUCCESS,  
                data:rows[0],     
                status:1                    
            };
          
        } else {
            conn.release();
            return {
                message: ERROR_MSG.OTP_NOT_MATCH_VERIFY,
                status: 0
            };  
           
        }
       
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}

module.exports.sendOTP = async (body) => {   
    try {
        var conn = await connection.getConnection();     
        let payloadData = body
        // console.log("Payload")
        // console.log(payloadData)

        // payloadData.otp = generateRandomNumber();
        payloadData.otp = 1234
        payloadData.logo = BaseURL+'/PoliciCueLogo.png'
        const [rows]  =  await conn.execute('SELECT * FROM users WHERE email = ? AND phone = ?',[payloadData.email,payloadData.phone]);      
        if (rows.length > 0) {
            conn.release();

            if(rows[0].IsOtpVerified == 1){
                return {
                    message: ERROR_MSG.EMAIL_ALREADY,
                    status: 0
                };
            }
            // Send OTP
            const userId = rows[0].id;  
            await conn.execute('UPDATE users SET otp = ? WHERE id = ?',[payloadData.otp, userId]);
            conn.release(); 
                    
            const subject = "Polici Cue - OTP(One Time Password)";
            const from = 'Polici Cue <testing.mobileprogramming@gmail.com>';
            const to = payloadData.email;  

            const message = await templateOtp.otpTemplate(payloadData)
            mail.mailfunction(from, to, subject, message);  
            //  SEND OTP SMS 
            // sendSMS(payloadData.phone,payloadData.otp)
            return {
                message: ERROR_MSG.OTP_SEND,
                status: 1,
                data: payloadData.otp
            };
        } else {
    
            const [rows]  = await conn.execute(`INSERT INTO users (email,phone,otp) VALUES(?,?,?)`,
            [payloadData.email,payloadData.phone,payloadData.otp]) ;
        
            const subject = "Polici Cue - OTP(One Time Password)";
            const from = 'Polici Cue <testing.mobileprogramming@gmail.com>';
            const to = payloadData.email;  
            const message = await templateOtp.otpTemplate(payloadData)
            mail.mailfunction(from, to, subject, message);     
            // SEND OTP SMS 
            // sendSMS(payloadData.phone,payloadData.otp)
                
            conn.release();
            return {              
                message: ERROR_MSG.OTP_SEND,
                status: 1,
                data:payloadData.otp             
            };
           
        }
       
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}

module.exports.socialLogin = async (body) => {   
    try {     
        var conn = await connection.getConnection();    
       
        let payloadData = body
        console.log(payloadData)
        if(payloadData.type == 1){ // FOR Facebook 
            var [rows]  =  await conn.execute('SELECT * FROM users WHERE (email = ? AND role = ? AND fb_token = ? )',
            [payloadData.email,"Normal",payloadData.socialId]);    
           
       
        }  else {
            var [rows]  =  await conn.execute('SELECT * FROM users WHERE (email = ? AND role = ? AND google_token = ? )',
            [payloadData.email,"Normal",payloadData.socialId]);  
        }
       
        if (rows.length > 0) {            
            console.log("-- IF part called---") 
            console.log(rows)    
            // if(rows[0].IsOtpVerified == 0){
            //     return {
            //         message: "Email already exists.Please login into account!",
            //         status: 0
            //     };
            // }
            if(rows[0].isDeleted == 1){
                conn.release();
                return {
                    message: ERROR_MSG.ACC_DELETE,
                    status: 0
                };
            }
            if(rows[0].isBlocked == 1){
                conn.release();
                return {
                    message: ERROR_MSG.ACC_BLOCK,
                    status: 0
                };
            }
                      
            const token = getJwtToken(payloadData.email, rows[0].id)
            conn.release();           
            rows[0].token = token 
            delete rows[0].password              
            return {  
                message:'success',  
                data:rows[0],     
                status:1              
            };
        } else {
            console.log("-- else part called---")
            const [rows]  =  await conn.execute('SELECT * FROM users WHERE (email = ? AND role = ? )',[payloadData.email,"Normal"]);  
            if (rows.length == 0) {   // IF no record found
            //    console.log("---- No record found ---")
                conn.release();     
                if(payloadData.type == 1){  // FOR Facebook 
                    var [rows_fb]  = await conn.execute(`INSERT INTO users (email,fb_token) VALUES(?,?)`,
                    [payloadData.email,payloadData.socialId]) ;
                } else {
                    var [rows_fb]  = await conn.execute(`INSERT INTO users (email,google_token) VALUES(?,?)`,
                    [payloadData.email,payloadData.socialId]) ;
                }
                // console.log(rows_fb)                           
                const token = getJwtToken(payloadData.email, rows_fb.insertId)
                var [rows_check]  =  await conn.execute('SELECT * FROM users WHERE id = ? ',[rows_fb.insertId]);  
                conn.release();
            
                rows_check[0].token = token 
                delete rows_check[0].password              
                return {  
                    message:'success',  
                    data:rows_check[0],     
                    status:1              
                };
    
            } else {
                console.log("--- second else part called ==")
                console.log(rows[0].id)
                const userId = rows[0].id;  
                if(payloadData.type == 1){  // FOR Facebook 
                    await conn.execute('UPDATE users SET fb_token = ? WHERE id = ?',[ payloadData.socialId, userId]);           
                } else {
                    await conn.execute('UPDATE users SET google_token = ? WHERE id = ?',[ payloadData.socialId, userId]);            
                }
               
                const token = getJwtToken(payloadData.email, rows[0].id)             
                conn.release();

                rows[0].token = token 
                delete rows[0].password              
                return {  
                    message:ERROR_MSG.SUCCESS,  
                    data:rows[0],     
                    status:1              
                };

            }


            
        }
       
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}


/** **********************************************************************
 *                  List of Change password  Related Function
 **************************************************************************/
module.exports.resetPassword = async (req) => {
    try {
        var conn = await connection.getConnection();     
        var [rows] =  await conn.execute('SELECT id FROM users WHERE id = ? ',[req.userId]); 
        if(rows[0].length == 0 ){
            conn.release();
            return {    
                message:'User does not exists'  ,
                status: 0           
            };
        }
        if(rows[0].firstTimeLogin == 1 ){
            conn.release();
            return {    
                message:'User already reset password at first time'  ,
                status: 0           
            };
        }
        const password = await bcrypt.hash(req.new_pass, 12);            
        await conn.execute('UPDATE users SET password = ?, firstTimeLogin = ? WHERE id = ?',[ password, 1, req.userId]);
        conn.release(); 
        return {    
            message:'Password reset successfully.'  ,
            status:1                  
        };
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}

module.exports.changePassword = async (req) => {
    try {
        var conn = await connection.getConnection();     
        var [rows] =  await conn.execute('SELECT * FROM users WHERE id = ? ',[req.userId]); 

        if(rows[0].isNormalSignup == 0){
            conn.release();
            return {
                message: ERROR_MSG.SOCIALLOGIN,
                status:0
            };
        }

        const isEqual = await bcrypt.compare(req.current_pass, rows[0].password);
        if (!isEqual) {
            conn.release();
            return {
                message: ERROR_MSG.OLD_PWD_INCORRECT,
                status:0
            };
        } else {
            const password = await bcrypt.hash(req.new_pass, 12);            
            var result =  await conn.execute('UPDATE users SET password = ? WHERE id = ?',[password, req.userId]);
            conn.release(); 
            return {    
                message: ERROR_MSG.SUCCESS ,
                status:1                  
            };
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}

module.exports.forgotPassword = async (email) => {
    const subject = "Polici Cue - Forgot Password!";
    const from = 'Polici Cue <testing.mobileprogramming@gmail.com>';
    const to = email;
    var conn = await connection.getConnection();
    const [rows] =  await conn.execute('SELECT id, fullName FROM users WHERE email = ? AND isDeleted = ?  AND role = ? ',[email,0,"Normal"]); 
  
    if (rows.length == 0) {
        conn.release()
        return {
            message:ERROR_MSG.EMAIL_NOT_EXISTS,
            status:0
        };
    }

    if(rows[0].isNormalSignup == 0){
        conn.release();
        return {
            message: ERROR_MSG.SOCIALLOGIN,
            status:0
        };
    }
    
    const password = generatePassword();
    let resetToken = generateRandomString(50);
    let resetTokenExpire = Date.now() + 3600000;
    const hashPassword = await bcrypt.hash(password, 12);
    const first_name = rows[0].firstName;
    const userId = rows[0].id;
   
    var rs = await conn.execute('UPDATE users SET resetPasswordToken = ? , resetPasswordExpire = ? WHERE id = ?',[resetToken,resetTokenExpire,userId]);
    conn.release();
    let payloadData = {}
    payloadData.password = password
    payloadData.first_name = first_name
    payloadData.logo = BaseURL+'/PoliciCueLogo.png'
   
    // create url form reset password   
    const url = `https://policiecue-app.mobileprogramming.net/reset/${resetToken}`;
    payloadData.url = url;
    const message = await templateForgot.forgotTemplate(payloadData)
    mail.mailfunction(from, to, subject, message)
    return {    
        message: ERROR_MSG.SUCCESS,
        status:1                  
    };
}

module.exports.resetForgotPassword = async (req) => {
    try {
       
        var conn = await connection.getConnection();   
        let time_now = Date.now() ; 
        var [rows] =  await conn.execute('SELECT * FROM users WHERE resetPasswordToken = ? AND resetPasswordExpire >= ?',[req.resetPasswordToken,time_now]); 
        if(rows.length == 0){
            conn.release(); 
            return {    
                message:ERROR_MSG.RESETTOKEN,
                status:0              
            };
        }
      
        const password = await bcrypt.hash(req.new_pass, 12);            
        await conn.execute('UPDATE users SET password = ? , resetPasswordToken = ? , resetPasswordExpire = ?  WHERE id = ?',[password,'','',rows[0].id]);      
        conn.release(); 
        return {    
            message: ERROR_MSG.SUCCESS ,
            status:1                  
        };
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}



/** **********************************************************************
 *                  List of User profile  Related Function
**************************************************************************/
module.exports.updateProfile = async (req) => {
    try {
        var conn = await connection.getConnection();  
        
        let userId = req.userId
        delete req.userId;     
        const result = await commonModel.updateData('users',userId, req);
        const rows = await commonModel.getUserByUid(userId);      
        conn.release(); 
        return {    
            message: ERROR_MSG.SUCCESS,
            status:1,
            data:rows[0]             
        };
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}

module.exports.getProfile = async (req) => {   
    try {         
        var conn = await connection.getConnection();   
        const [rows]  =  await conn.execute('SELECT id,fullName,email,phone,isBlocked,isDeleted FROM users WHERE id = ?',[req.userId]); 
        if (rows.length == 0) {
            conn.release();
            return {
                message: ERROR_MSG.ACC_DELETE,
                status:0
            };
        } else {           
            conn.release();
            return {  
                message: ERROR_MSG.SUCCESS,
                status: 1,
                data:rows         
            };           
        }
       
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}



/** **********************************************************************
 *                  List of Car insurance  Related Function
**************************************************************************/
module.exports.getCarMake = async (req) => {   
    try {         
        var conn = await connection.getConnection();   
        const [rows]  =  await conn.execute('SELECT * FROM vehiclemake'); 
        if (rows.length == 0) {
            conn.release();
            return {
                message: ERROR_MSG.NO_RECORD,
                status:0
            };
        } else {           
            conn.release();
            return {  
                message: ERROR_MSG.SUCCESS,
                status: 1,
                data:rows         
            };           
        }
       
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}

module.exports.getCarModel = async (req) => {   
    try {    
        const MakeId = req.id     
        var conn = await connection.getConnection();   
        const [rows]  =  await conn.execute(`
        SELECT vehiclevariant.id as variantId, vehiclemake.id as makeId,
        vehiclemodel.id as modelId, vehiclemake.name as makeName,vehiclemake.logo,vehiclemodel.name as modelName,
        vehiclevariant.name as variantName FROM vehiclevariant 
        INNER JOIN vehiclemodel on vehiclemodel.id = vehiclevariant.vehicleModelId 
        INNER JOIN vehiclemake on vehiclemake.id = vehiclevariant.vehicleMakeId
        WHERE vehiclevariant.vehicleMakeId = ?`,[MakeId]); 
        if (rows.length == 0) {
            conn.release();
            return {
                message: ERROR_MSG.NO_RECORD,
                status:0
            };
        } else {           
            conn.release();
            var group_to_values = rows.reduce(function (obj, item) {
                obj[item.makeName] = obj[item.makeName] || [];
                obj[item.makeName].push(item);
                return obj;
            }, {});    
            // console.log(group_to_values)
            var grouped = Object.keys(group_to_values).map(function (key) {
                return {
                    make: key,
                    logo:group_to_values[key][0].logo, 
                    manufacturingName:group_to_values[key][0].manufacturingName,
                    model:group_to_values[key][0].modelName, 
                    variant: group_to_values[key]
                };
            });

            return {  
                message: ERROR_MSG.SUCCESS,
                status: 1,
                data:grouped         
            };           
        }
       
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}

module.exports.getRTO = async (req) => {   
    try {    
        const MakeId = req.id     
        var conn = await connection.getConnection();   
        const [rows]  =  await conn.execute(`SELECT * from rto`); 
        if (rows.length == 0) {
            conn.release();
            return {
                message: ERROR_MSG.NO_RECORD,
                status:0
            };
        } else {           
            conn.release();
            var group_to_values = rows.reduce(function (obj, item) {
                obj[item.state] = obj[item.state] || [];
                obj[item.state].push(item);
                return obj;
            }, {});    
            // console.log(group_to_values)
            var grouped = Object.keys(group_to_values).map(function (key) {
                return {
                    id: group_to_values[key][0].id,
                    codeName:group_to_values[key][0].codeName, 
                    capital:group_to_values[key][0].capital, 
                    name:group_to_values[key][0].state, 
                    districts: group_to_values[key]
                };
            });

            return {  
                message: ERROR_MSG.SUCCESS,
                status: 1,
                data:grouped         
            };           
        }
       
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}

/** **********************************************************************
 *                  List of General Function
 **************************************************************************/
function generatePassword() {
    var length = 8,
        charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789",
        retVal = "";
    for (var i = 0, n = charset.length; i < length; ++i) {
        retVal += charset.charAt(Math.floor(Math.random() * n));
    }
    return retVal;
}

function generateRandomNumber () {
	var val = Math.floor(1000 + Math.random() * 9000);
    console.log(val);
    return val
};


function generateRandomString (stringLength) {
	let text = '';
	let possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@$_";

	do {
		text = '';
		for (let i = 0; i < stringLength; i++)
			text += possible.charAt(Math.floor(Math.random() * possible.length));
	} while (!(/((?=.*\d)(?=.*[A-Z])(?=.*\W).{8,8})/.test(text)));
	return text;
};


function getJwtToken(email,userId){
    return jwt.sign({
        email: email,
        user_id: userId,                   
        // phone :rows[0].phone                   
    }, process.env.JWT_KEY, {
        expiresIn: "10d"
    });
}



function sendSMS (phone,otp)  {
    console.log("enter in send msm")
    const Vonage = require('@vonage/server-sdk');
    const vonage = new Vonage({
        apiKey: "3d19f803",
        apiSecret: "k0VdvUKMnucQRjYS"
    })
    const from = "Polici Cue"
    const to = "91"+phone
    const text = 'Your one time password :'+otp
    console.log(to)
    console.log(text)
    vonage.message.sendSms(from, to, text, (err, responseData) => {
        if (err) {
            console.log(err);
        } else {
            console.log("--success --")
            console.log(responseData.messages)
            if(responseData.messages[0]['status'] === "0") {
                console.log("Message sent successfully.");
                return true
            } else {
                console.log(`Message failed with error: ${responseData.messages[0]['error-text']}`);
                // res.send(`Message failed with error: ${responseData.messages[0]['error-text']}`);
                return false
            }
        }
    })
}

module.exports.blockUser = async (req, res, next) => {
    try{
        var conn = await connection.getConnection();     
        console.log(req);
        const [rows] = await conn.execute("UPDATE users set isBlocked = ?  where id = ?", [1, req.user_id]);
        if (rows.length == 0) {
            conn.release();
            return {
                message: ERROR_MSG.NO_RECORD,
                status:0
            };
        } else {           
            conn.release();
            return {  
                message: ERROR_MSG.SUCCESS,
                status: 1,
                data:rows         
            };           
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}

module.exports.unblockUser = async (req, res, next) => {
    try{
        var conn = await connection.getConnection();     
        const [rows] = await conn.execute("UPDATE users set isBlocked = ?  where id = ?", [false, req.user_id]);
        if (rows.length == 0) {
            conn.release();
            return {
                message: ERROR_MSG.NO_RECORD,
                status:0
            };
        } else {           
            conn.release();
            return {  
                message: ERROR_MSG.SUCCESS,
                status: 1,
                data:rows         
            };           
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}

