'user strict';

const  connection  = require('../../../db.js');
const  ERROR_MSG =   require('../message.json')

module.exports.getAllRoles = async (req, res, next) => {
    try{
        var conn = await connection.getConnection();     
        const [rows] = await conn.execute("select  * from roles");
        if (rows.length == 0) {
            conn.release();
            return {
                message: ERROR_MSG.NO_RECORD,
                status:0
            };
        } else {           
            conn.release();
            return {  
                message: ERROR_MSG.SUCCESS,
                status: 1,
                data:rows         
            };           
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}

module.exports.addRole = async (req, res, next) => {
    try{
        var conn = await connection.getConnection();  
        const [rows] = await conn.execute("INSERT INTO roles (name) VALUES(?)",[req.role_name]);

        if (rows.length == 0) {
            conn.release();
            return {
                message: ERROR_MSG.NO_RECORD,
                status:0
            };
        } else {           
            conn.release();
            return {  
                message: ERROR_MSG.SUCCESS,
                status: 1,
                data:rows         
            };           
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}

module.exports.deleteRole = async (req, res, next) => {
    try{
        var conn = await connection.getConnection();  
        const [rows] = await conn.execute("DELETE from roles where id = ?",[req.role_id]);

        if (rows.length == 0) {
            conn.release();
            return {
                message: ERROR_MSG.NO_RECORD,
                status:0
            };
        } else {           
            conn.release();
            return {  
                message: ERROR_MSG.SUCCESS,
                status: 1,
                data:rows         
            };           
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}

module.exports.updateRole = async (req, res, next) => {
    try{
        var conn = await connection.getConnection();     
        const [rows] = await conn.execute("UPDATE roles set name = ?  where id = ?", [req.role_name, req.role_id]);
        if (rows.length == 0) {
            conn.release();
            return {
                message: ERROR_MSG.NO_RECORD,
                status:0
            };
        } else {           
            conn.release();
            return {  
                message: ERROR_MSG.SUCCESS,
                status: 1,
                data:rows         
            };           
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}

module.exports.getUserRole = async (req, res, next) => {
    try{
        var conn = await connection.getConnection();     
        const [rows] = await conn.execute("select r.id, r.name from userRoles ur join roles r on r.id  = ur.roleId where ur.userId = ?", [req.user_id]);
        if (rows.length == 0) {
            conn.release();
            return {
                message: ERROR_MSG.NO_RECORD,
                status:0
            };
        } else {           
            conn.release();
            return {  
                message: ERROR_MSG.SUCCESS,
                status: 1,
                data:rows         
            };           
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}

module.exports.assignRole = async (req, res, next) => {
    try{
        var conn = await connection.getConnection();  
        const [rows] = await conn.execute("INSERT INTO userRoles (userId, roleId) VALUES(?,?)",[req.user_id,req.role_id]);

        if (rows.length == 0) {
            conn.release();
            return {
                message: ERROR_MSG.NO_RECORD,
                status:0
            };
        } else {           
            conn.release();
            return {  
                message: ERROR_MSG.SUCCESS,
                status: 1,
                data:rows         
            };           
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}

module.exports.removeAssignedRole = async (req, res, next) => {
    try{
        var conn = await connection.getConnection();  
        const [rows] = await conn.execute("DELETE from userRoles where id = ?",[req.user_roles_id]);

        if (rows.length == 0) {
            conn.release();
            return {
                message: ERROR_MSG.NO_RECORD,
                status:0
            };
        } else {           
            conn.release();
            return {  
                message: ERROR_MSG.SUCCESS,
                status: 1,
                data:rows         
            };           
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}

module.exports.getAllUserRoles= async (req, res, next) => {
    try{
        var conn = await connection.getConnection();     
        const [rows] = await conn.execute("select  * from userRoles");
        if (rows.length == 0) {
            conn.release();
            return {
                message: ERROR_MSG.NO_RECORD,
                status:0
            };
        } else {           
            conn.release();
            return {  
                message: ERROR_MSG.SUCCESS,
                status: 1,
                data:rows         
            };           
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}

module.exports.getAllPermissions = async (req, res, next) => {
    try{
        var conn = await connection.getConnection();     
        const [rows] = await conn.execute("select  * from permissions");
        if (rows.length == 0) {
            conn.release();
            return {
                message: ERROR_MSG.NO_RECORD,
                status:0
            };
        } else {           
            conn.release();
            return {  
                message: ERROR_MSG.SUCCESS,
                status: 1,
                data:rows         
            };           
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}

module.exports.addPermission = async (req, res, next) => {
    try{
        var conn = await connection.getConnection();  
        const [rows] = await conn.execute("INSERT INTO permissions (name) VALUES(?)",[req.permission_name]);

        if (rows.length == 0) {
            conn.release();
            return {
                message: ERROR_MSG.NO_RECORD,
                status:0
            };
        } else {           
            conn.release();
            return {  
                message: ERROR_MSG.SUCCESS,
                status: 1,
                data:rows         
            };           
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}

module.exports.deletePermission = async (req, res, next) => {
    try{
        var conn = await connection.getConnection();  
        const [rows] = await conn.execute("DELETE from permissions where id = ?",[req.permission_id]);

        if (rows.length == 0) {
            conn.release();
            return {
                message: ERROR_MSG.NO_RECORD,
                status:0
            };
        } else {           
            conn.release();
            return {  
                message: ERROR_MSG.SUCCESS,
                status: 1,
                data:rows         
            };           
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}

module.exports.updatePermission = async (req, res, next) => {
    try{
        var conn = await connection.getConnection();     
        const [rows] = await conn.execute("UPDATE permissions set name = ?  where id = ?", [req.permission_name, req.permission_id]);
        if (rows.length == 0) {
            conn.release();
            return {
                message: ERROR_MSG.NO_RECORD,
                status:0
            };
        } else {           
            conn.release();
            return {  
                message: ERROR_MSG.SUCCESS,
                status: 1,
                data:rows         
            };           
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}

module.exports.getPermissionsAssigned = async (req, res, next) => {
    try{
        var conn = await connection.getConnection();     
        const [rows] = await conn.execute("select p.id, p.name from permissionUsers pu join permissions p on p.id  = pu.permissionId where pu.userId = ?", [req.user_id]);

        if (rows.length == 0) {
            conn.release();
            return {
                message: ERROR_MSG.NO_RECORD,
                status:0
            };
        } else {           
            conn.release();
            return {  
                message: ERROR_MSG.SUCCESS,
                status: 1,
                data:rows         
            };           
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}

module.exports.assignPermission = async (req, res, next) => {
    try{
        var conn = await connection.getConnection();  
        const [rows] = await conn.execute("INSERT INTO permissionUsers (userId, permissionId) VALUES(?,?)",[req.user_id,req.permission_id]);

        if (rows.length == 0) {
            conn.release();
            return {
                message: ERROR_MSG.NO_RECORD,
                status:0
            };
        } else {           
            conn.release();
            return {  
                message: ERROR_MSG.SUCCESS,
                status: 1,
                data:rows         
            };           
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}

module.exports.removeAssignedPermission = async (req, res, next) => {
    try{
        var conn = await connection.getConnection();  
        const [rows] = await conn.execute("DELETE from permissionUsers where id = ?",[req.permission_users_id]);

        if (rows.length == 0) {
            conn.release();
            return {
                message: ERROR_MSG.NO_RECORD,
                status:0
            };
        } else {           
            conn.release();
            return {  
                message: ERROR_MSG.SUCCESS,
                status: 1,
                data:rows         
            };           
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}

module.exports.getAllPermissionUsers= async (req, res, next) => {
    try{
        var conn = await connection.getConnection();     
        const [rows] = await conn.execute("select  * from permissionUsers");
        if (rows.length == 0) {
            conn.release();
            return {
                message: ERROR_MSG.NO_RECORD,
                status:0
            };
        } else {           
            conn.release();
            return {  
                message: ERROR_MSG.SUCCESS,
                status: 1,
                data:rows         
            };           
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}



