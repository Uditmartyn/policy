'user strict';

const { values } = require('underscore');
const  connection  = require('../../../db.js');
const  ERROR_MSG =   require('../message.json');

module.exports.getPolicyTypes = async (req, res, next) => {
    try{
        var conn = await connection.getConnection();     
        const [rows] = await conn.execute(`SELECT * from typeof_insurance_policies`);
        if (rows.length == 0) {
            conn.release();
            return {
                message: ERROR_MSG.NO_RECORD,
                status:0
            };
        } else {           
            conn.release();
            return {  
                message: ERROR_MSG.SUCCESS,
                status: 1,
                data:rows         
            };           
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}
module.exports.addProposerDetails = async (tableName, body) => {    
    try{
        var conn = await connection.getConnection();     
        const query = "INSERT into  "+tableName+"  (" + Object.keys(body).map(key => `${key}`).join(", ") + ") values ("+Object.keys(body).map(key => `?`).join(", ")+")";   
        const [rows] = await conn.execute(query,Object.values(body)); 
        if (rows.length == 0) {
            conn.release();
            return {
                message: ERROR_MSG.NO_RECORD,
                status:0
            };
        } else {           
            conn.release();
            return {  
                message: ERROR_MSG.SUCCESS,
                status: 1,
                data:rows         
            };           
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }

}
module.exports.updateData = async (body, tableName, portfolioId ) => {
    try{
        var conn = await connection.getConnection();     
        const query = "UPDATE "+tableName+" SET " + Object.keys(body).map(key => `${key} = ?`).join(", ") + " WHERE id = ?";    
        const parameters = [...Object.values(body), portfolioId];   
        const [rows] = await conn.execute(query, parameters);  

        if (rows.length == 0) {
            conn.release();
            return {
                message: ERROR_MSG.NO_RECORD,
                status:0
            };
        } else {           
            conn.release();
            return {  
                message: ERROR_MSG.SUCCESS,
                status: 1,
                data:rows         
            };           
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}

   
module.exports.addPolicyCoverage = async (tableName, body) => {
    try{
        var conn = await connection.getConnection();     
        const query = "INSERT into  "+tableName+"  (" + Object.keys(body).map(key => `${key}`).join(", ") + ") values ("+Object.keys(body).map(key => `?`).join(", ")+")";   
        const [rows] = await conn.execute(query,Object.values(body)); 
        
        if (rows.length == 0) {
            conn.release();
            return {
                message: ERROR_MSG.NO_RECORD,
                status:0
            };
        } else {           
            conn.release();
            return {  
                message: ERROR_MSG.SUCCESS,
                status: 1,
                data:rows,
                     
            };           
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}


module.exports.addPremiumDetails = async (tableName, body) => {    
    try{
        var conn = await connection.getConnection();     
        const query = "INSERT into  "+tableName+"  (" + Object.keys(body).map(key => `${key}`).join(", ") + ") values ("+Object.keys(body).map(key => `?`).join(", ")+")";   
        const [rows] = await conn.execute(query,Object.values(body)); 
        if (rows.length == 0) {
            conn.release();
            return {
                message: ERROR_MSG.NO_RECORD,
                status:0
            };
        } else {           
            conn.release();
            return {  
                message: ERROR_MSG.SUCCESS,
                status: 1,
                data:rows         
            };           
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }

}
module.exports.addBankDetails = async (tableName, body) => {    
    try{
        var conn = await connection.getConnection();     
        const query = "INSERT into  "+tableName+"  (" + Object.keys(body).map(key => `${key}`).join(", ") + ") values ("+Object.keys(body).map(key => `?`).join(", ")+")";   
        const [rows] = await conn.execute(query,Object.values(body)); 
        if (rows.length == 0) {
            conn.release();
            return {
                message: ERROR_MSG.NO_RECORD,
                status:0
            };
        } else {           
            conn.release();
            return {  
                message: ERROR_MSG.SUCCESS,
                status: 1,
                data:rows         
            };           
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }

}

module.exports.checkUserExists = async (tableName, phoneNumber) => {
    try{
        var conn = await connection.getConnection();     
        const [rows] = await conn.execute(`SELECT * FROM ${tableName} WHERE phoneNumber = ${phoneNumber}`);
        if (rows.length == 0) {
            conn.release();
            return {
                message: ERROR_MSG.NO_RECORD,
                status:0
            };
        } else {           
            conn.release();
            return {  
                message: ERROR_MSG.SUCCESS,
                status: 1,
                data:rows         
            };           
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}

module.exports.getCustomerDetails = async (req, res, next) => {
    try{
        var conn = await connection.getConnection();     
        const [rows] = await conn.execute(`SELECT * FROM proposerdetails
        INNER JOIN policycoverage ON proposerdetails.id = policycoverage.customerId
        INNER JOIN premiumdetails ON proposerdetails.id = premiumdetails.customerId
        INNER JOIN bankdetails ON proposerdetails.id = bankdetails.customerId `);

        if (rows.length == 0) {
            conn.release();
            return {
                message: ERROR_MSG.NO_RECORD,
                status:0
            };
        } else {           
            conn.release();
            return {  
                message: ERROR_MSG.SUCCESS,
                status: 1,
                data:rows         
            };           
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}



