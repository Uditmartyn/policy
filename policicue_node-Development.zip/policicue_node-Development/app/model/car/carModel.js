'user strict';

const  connection  = require('../../../db.js');
const  ERROR_MSG =   require('../message.json')
module.exports.getCarPolicyTypes = async (req, res, next) => {
    try{
        var conn = await connection.getConnection();     
        const [rows] = await conn.execute("select id, name, term, code, active from carPolicyTypes where active = ?", [1]);
        if (rows.length == 0) {
            conn.release();
            return {
                message: ERROR_MSG.NO_RECORD,
                status:0
            };
        } else {           
            conn.release();
            return {  
                message: ERROR_MSG.SUCCESS,
                status: 1,
                data:rows         
            };           
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}
module.exports.getMakeModelVariant = async (req) => {   
    try {    
        const MakeId = req.id     
        var conn = await connection.getConnection();   
        const [rows]  =  await conn.execute(`
        SELECT vehiclevariant.id as variantId, vehiclemake.id as makeId,
        vehiclemodel.id as modelId, vehiclemake.name as makeName,vehiclemake.logo,vehiclemodel.name as modelName,
        vehiclevariant.name as variantName FROM vehiclevariant 
        INNER JOIN vehiclemodel on vehiclemodel.id = vehiclevariant.vehicleModelId 
        INNER JOIN vehiclemake on vehiclemake.id = vehiclevariant.vehicleMakeId
        WHERE vehiclevariant.vehicleMakeId = ?`,[MakeId]); 
        
        if (rows.length == 0) {
            conn.release();
            return {
                message: ERROR_MSG.NO_RECORD,
                status:0
            };
        } else {           
            conn.release();
            function groupBy(objectArray, property) {
                return objectArray.reduce(function (acc, obj) {
                  let key = obj[property]
                  if (!acc[key]) {
                    acc[key] = []
                  }
                  acc[key].push(obj)
                  return acc
                }, {})
            }  
            // console.log(groupedMake)
            let groupedModel = groupBy(rows, 'modelName')
            var grouped = Object.keys(groupedModel).map(function (key) {
                return {
                    make: groupedModel[key][0].makeName,
                    logo:groupedModel[key][0].logo, 
                    manufacturingName:groupedModel[key][0].manufacturingName,
                    model:key, 
                    variant: groupedModel[key]
                };
            });
            conn.release();
            return {  
                message: ERROR_MSG.SUCCESS,
                status: 1,
                data:grouped         
            };           
        }
       
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}
