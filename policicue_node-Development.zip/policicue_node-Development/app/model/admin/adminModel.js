'user strict';
const  connection  = require('../../../db.js');
const  template =  require('../../emailTemplate/signupTemplate')
const commonModel = require('../commonModel')
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const fs = require('fs');
const mail = require('../../middleware/mail.js');
const readXlsxFile = require("read-excel-file/node");
const path = require('path');     
const AWS = require("aws-sdk");
const { exit } = require('process');
const mysql = require('mysql2');

/* login user method */
module.exports.login = async (email, password) => {   
    try {        
        var conn = await connection.getConnection();     
        const [rows]  =  await conn.execute('SELECT * FROM users WHERE email = ? AND role = "Admin"',[email]); 
       
        if (rows.length > 0) {
            if(rows[0].isDeleted == 1){
                conn.release();
                return {
                    message: "Your account not longer exists with liberty mutual.",
                    loggedin: 0
                };
            }
            if(rows[0].isBlocked == 1){
                conn.release();
                return {
                    message: "Your account has beed blocked.",
                    loggedin: 0
                };
            }
            const isEqual = await bcrypt.compare(password, rows[0].password);           
            if (!isEqual) {
                conn.release();
                return {
                    message: "Please enter correct password.",
                    loggedin: 0
                };
            }
            else {

                //genrate json web token
                const token = jwt.sign({
                    email: email,
                    user_id: rows[0].id,
                    user_type :"ADMIN"
                }, process.env.JWT_KEY, {
                    expiresIn: "2d"
                });
                conn.release();
                rows[0].token = token 
                delete rows[0].password              
                return {  
                    message:'success', 
                    data:rows[0],     
                    status:1,
                    loggedin: 1
                };
            }
        }

        conn.release();
        return {
            message: "Please enter correct email id.",
            loggedin: 0
        };
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}
