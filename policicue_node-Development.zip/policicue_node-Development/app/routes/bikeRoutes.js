var express = require('express');
var router = express.Router();
const bikeController = require('../controller/bikeController');

router.get('/getBikePolicyTypes',bikeController.getBikePolicyTypes);
router.get('/getBikeModels',bikeController.getBikeModels);
router.get('/getBikeMakes',bikeController.getBikeMakes);

module.exports = router;
