var express = require('express');
var router = express.Router();
const department = require('../controller/departmentController');

router.get('/getAllDepartments', department.getAllDepartments);
router.post('/addDepartment', department.addDepartment);
router.post('/deleteDepartment', department.deleteDepartment);
router.post('/updateDepartment', department.updateDepartment);

module.exports = router;