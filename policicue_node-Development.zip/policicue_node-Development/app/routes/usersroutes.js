var express = require('express');
const rateLimit = require("express-rate-limit");
var router = express.Router();
const userController = require('../controller/userController');
const valid_recruiter = require('../middleware/valid_recruiter');
// Rate limiter 
const loginRateLimiter = rateLimit({
    windowMs: 5 * 60 * 1000 , // 5 min window
    max: 50, // start blocking after 5 requests
    message:
      "Too many request from this IP, please try again after an hour"
});
const forgotPwdRateLimiter = rateLimit({
    windowMs: 5 * 60 * 1000 , // 5 min window
    max: 50, // start blocking after 5 requests
    message:
      "Too many request from this IP, please try again after an hour"
});

/** **********************************************************************
 *                  List of User Related  Routes 
**************************************************************************/
router.post('/login',userController.validate('login'),userController.signIn);
router.post('/signup',userController.validate('signup'),userController.signup);
router.post('/sendOTP',userController.validate('sendOTP'),userController.sendOTP);
router.post('/socialLogin',userController.validate('socialLogin'),userController.socialLogin);
router.post('/forgotPassword',forgotPwdRateLimiter,userController.validate('forgotpass'),userController.forgotPassword);
router.post('/resetForgotPassword',forgotPwdRateLimiter,userController.validate('resetForgotPassword'),userController.resetForgotPassword);
router.post('/changePassword',forgotPwdRateLimiter,valid_recruiter,userController.validate('changePassword'),userController.changePassword);
router.post('/resetPassword',valid_recruiter,userController.validate('resetPassword'),userController.resetPassword);
router.put('/updateProfile',valid_recruiter,userController.validate('updateProfile'),userController.updateProfile);
router.get('/getProfile',valid_recruiter,userController.getProfile);
router.get('/getCarMake',userController.getCarMake);
router.get('/getCarModel',userController.getCarModel);
router.get('/getRTO',userController.getRTO);
router.post('/blockUser',userController.blockUser);
router.post('/unblockUser',userController.unblockUser);

module.exports = router;