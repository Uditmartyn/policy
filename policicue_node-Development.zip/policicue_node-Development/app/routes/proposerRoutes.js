var express = require('express');
var router = express.Router();

const proposerController = require('../controller/proposerController');

router.get('/getpolicyTypes', proposerController.getPolicyTypes);
router.post('/addProposerDetails', proposerController.addProposerDetails)
router.post('/addpolicyCoverage', proposerController.addPolicyCoverage);
router.post('/addPremiumDetails', proposerController.addPremiumDetails);
router.post('/addBankDetails', proposerController.addBankDetails);
router.post('/updateProposerDetails', proposerController.updateProposerDetails);
router.post('/updatePolicyCoverage', proposerController.updatePolicyCoverage);
router.post('/updatePremiumDetails', proposerController.updatePremiumDetails);
router.post('/updateBankDetails', proposerController.updateBankDetails);
router.get('/getCustomerDetails', proposerController.getCustomerDetails);


module.exports = router;
