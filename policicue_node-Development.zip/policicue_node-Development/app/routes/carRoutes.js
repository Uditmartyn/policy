var express = require('express');
var router = express.Router();
const carController = require('../controller/carController');

router.get('/getCarPolicyTypes',carController.getCarPolicyTypes);
router.post('/getMakeModelVariants', carController.getMakeModelVariant);

module.exports = router;