var express = require('express');
var router = express.Router();
const adminController = require('../controller/adminController');
const is_admin = require('../middleware/is_auth');
const upload = require("../middleware/upload");

// Route for admin login
router.post('/login',adminController.validate('login'),adminController.signIn);

module.exports = router;