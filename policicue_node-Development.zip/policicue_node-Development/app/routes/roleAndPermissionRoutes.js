var express = require('express');
var router = express.Router();
const roleAndPermission = require('../controller/roleAndPermissionController');

router.get('/getAllRoles',roleAndPermission.getAllRoles);
router.post('/getUserRole', roleAndPermission.getUserRole);
router.post('/addRole', roleAndPermission.addRole);
router.post('/deleteRole', roleAndPermission.deleteRole);
router.post('/updateRole', roleAndPermission.updateRole);
router.post('/assignRole', roleAndPermission.assignRole);
router.post('/removeAssignedRole', roleAndPermission.removeAssignedRole);
router.get('/getAllUserRoles',roleAndPermission.getAllUserRoles);
router.get('/getAllPermissions',roleAndPermission.getAllPermissions);
router.post('/getPermissionsAssigned', roleAndPermission.getPermissionsAssigned);
router.post('/addPermission', roleAndPermission.addPermission);
router.post('/deletePermission', roleAndPermission.deletePermission);
router.post('/updatePermission', roleAndPermission.updatePermission);
router.post('/assignPermission', roleAndPermission.assignPermission);
router.post('/removeAssignedPermission', roleAndPermission.removeAssignedPermission);
router.get('/getAllPermissionUsers',roleAndPermission.getAllPermissionUsers);

module.exports = router;