var express = require('express');
var router = express.Router();

const healthController = require('../controller/healthController');

router.get('/getcityPincodes', healthController.getcityPincode);
router.get('/getHealthInsurers', healthController.getHealthInsurers);
router.get('/getcoverAmountRange', healthController.getCoverAmount);
router.get('/getExistingIllness', healthController.getExistingIllness);
router.post('/addHealthCustomerDetails', healthController.addHealthCustomerDetails);


module.exports = router;
