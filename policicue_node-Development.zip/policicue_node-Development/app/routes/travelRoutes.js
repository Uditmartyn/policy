var express = require('express');
var router = express.Router();

const travelController = require('../controller/travelController');

router.get('/getCountriesList', travelController.getCountriesList);

module.exports = router;
