var express = require('express');
var router = express.Router();

const healthController = require('../controller/healthController');


router.get('/getcityPincodes', healthController.getcityPincode);
router.get('/getHealthInsurers', healthController.getHealthInsurers);
router.get('/getcoverAmountRange', healthController.getCoverAmount);
router.get('/getFamilyMembers', healthController.getFamilyMembers);
router.get('/getMedicalHistory', healthController.getMedicalHistory);
router.get('/getCashlessHospitals', healthController.getCashlessHospitals);
router.get('/getInnsurancePlans', healthController.getInsurersWithPlans);



module.exports = router;
