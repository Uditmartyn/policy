var express = require('express');
var router = express.Router();

const termController = require('../controller/termLifeController');

router.get('/getSalaryRange', termController.getsalaryRange);
router.get('/getLifeInsuranceCompanies', termController.getInsuranceCompanies);
router.post('/addlifeTermCustomerDetails', termController.addCustomerDetails);
router.get('/getCustomerDetails', termController.getCustomerDetails);
router.post('/addSaveForChild', termController.addCustomerDetails);
router.get('/getSaveForChild', termController.getSaveForChild);
router.post('/addInvestmentTaxplanningCustomerDetails', termController.addCustomerDetails);
router.get('/getaddInvestmentTaxplanningCustomerDetails', termController.getInvestmentTaxplanningCustomerdetails);
router.post('/addPensionRetirementCustomerDetails', termController.addCustomerDetails);
router.get('/getPensionRetirementCustomerDetails', termController.getPensionRetireCustomerDetails);



module.exports = router;
