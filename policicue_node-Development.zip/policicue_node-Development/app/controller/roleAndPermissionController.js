var roleAndPermission = require('../model/roleAndPermission/roleAndPermissionModel.js');

module.exports.getAllRoles = async (req, res, next) => {
    const result = await roleAndPermission.getAllRoles(req.body)

    if (result.status == 1) {
        res.status(200).json({ status: 1, "message": 'success', data: result.data });
    }
    else {
        res.status(200).json({ status: 0, "message": result.message });

    }
}

module.exports.getUserRole = async (req, res, next) => {
    
        const result = await roleAndPermission.getUserRole(req.body)
        if (result.status == 1) {       
            res.status(200).json({ status: 1, "message": 'success', data:result.data});       
        }
        else {
            res.status(200).json({ status: 0, "message": result.message });
        }
}

module.exports.addRole = async (req, res, next) => {

    const result = await roleAndPermission.addRole(req.body)
    if (result.status == 1) {       
        res.status(200).json({ status: 1, "message": 'success', data:result.data});       
    }
    else {
        res.status(200).json({ status: 0, "message": result.message });
    }
}

module.exports.deleteRole = async (req, res, next) => {

    const result = await roleAndPermission.deleteRole(req.body)
    if (result.status == 1) {       
        res.status(200).json({ status: 1, "message": 'success', data:result.data});       
    }
    else {
        res.status(200).json({ status: 0, "message": result.message });
    }
}

module.exports.assignRole = async (req, res, next) => {

    const result = await roleAndPermission.assignRole(req.body)
    if (result.status == 1) {       
        res.status(200).json({ status: 1, "message": 'success', data:result.data});       
    }
    else {
        res.status(200).json({ status: 0, "message": result.message });
    }
}

module.exports.removeAssignedRole = async (req, res, next) => {

    const result = await roleAndPermission.removeAssignedRole(req.body)
    if (result.status == 1) {       
        res.status(200).json({ status: 1, "message": 'success', data:result.data});       
    }
    else {
        res.status(200).json({ status: 0, "message": result.message });
    }
}

module.exports.updateRole = async (req, res, next) => {

    const result = await roleAndPermission.updateRole(req.body)
    if (result.status == 1) {       
        res.status(200).json({ status: 1, "message": 'success', data:result.data});       
    }
    else {
        res.status(200).json({ status: 0, "message": result.message });
    }
}

module.exports.getAllUserRoles = async (req, res, next) => {
    const result = await roleAndPermission.getAllUserRoles(req.body)

    if (result.status == 1) {
        res.status(200).json({ status: 1, "message": 'success', data: result.data });
    }
    else {
        res.status(200).json({ status: 0, "message": result.message });

    }
}

module.exports.getPermissionsAssigned = async (req, res, next) => {
    
    const result = await roleAndPermission.getPermissionsAssigned(req.body)
    if (result.status == 1) {       
        res.status(200).json({ status: 1, "message": 'success', data:result.data});       
    }
    else {
        res.status(200).json({ status: 0, "message": result.message });
    }
}

module.exports.getAllPermissions = async (req, res, next) => {

    const result = await roleAndPermission.getAllPermissions(req.body)
    if (result.status == 1) {       
        res.status(200).json({ status: 1, "message": 'success', data:result.data});       
    }
    else {
        res.status(200).json({ status: 0, "message": result.message });
    }
}

module.exports.addPermission = async (req, res, next) => {

    const result = await roleAndPermission.addPermission(req.body)
    if (result.status == 1) {       
        res.status(200).json({ status: 1, "message": 'success', data:result.data});       
    }
    else {
        res.status(200).json({ status: 0, "message": result.message });
    }
}

module.exports.deletePermission = async (req, res, next) => {

    const result = await roleAndPermission.deletePermission(req.body)
    if (result.status == 1) {       
        res.status(200).json({ status: 1, "message": 'success', data:result.data});       
    }
    else {
        res.status(200).json({ status: 0, "message": result.message });
    }
}

module.exports.updatePermission = async (req, res, next) => {

    const result = await roleAndPermission.updatePermission(req.body)
    if (result.status == 1) {       
        res.status(200).json({ status: 1, "message": 'success', data:result.data});       
    }
    else {
        res.status(200).json({ status: 0, "message": result.message });
    }
}

module.exports.assignPermission = async (req, res, next) => {

    const result = await roleAndPermission.assignPermission(req.body)
    if (result.status == 1) {       
        res.status(200).json({ status: 1, "message": 'success', data:result.data});       
    }
    else {
        res.status(200).json({ status: 0, "message": result.message });
    }
}

module.exports.removeAssignedPermission = async (req, res, next) => {

    const result = await roleAndPermission.removeAssignedPermission(req.body)
    if (result.status == 1) {       
        res.status(200).json({ status: 1, "message": 'success', data:result.data});       
    }
    else {
        res.status(200).json({ status: 0, "message": result.message });
    }
}

module.exports.getAllPermissionUsers = async (req, res, next) => {
    const result = await roleAndPermission.getAllPermissionUsers(req.body)

    if (result.status == 1) {
        res.status(200).json({ status: 1, "message": 'success', data: result.data });
    }
    else {
        res.status(200).json({ status: 0, "message": result.message });

    }
}



