//var commonModel = require('../model/commonModel');
const proposerModel = require('../model/proposer/proposerModel');
const  connection  = require('../../db.js');
var insertId;

/** method for getCityPincodes */
module.exports.getPolicyTypes = async (req, res, next) => {
    //res.send("this is the health controller");
    const result = await proposerModel.getPolicyTypes(req.body)

    if (result.status == 1) {
        console.log(result);
        res.status(200).json({ status: 1, "message": 'success', data: result.data });
    }
    else {
        res.status(200).json({ status: 0, "message": result.message });

    }
}
module.exports.addProposerDetails = async (req, res, next) => {
    const body = req.body;
    const tableName = 'proposerdetails';
    //res.send(body);
    const result = await proposerModel.addProposerDetails(tableName, body)
    insertId = result.data.insertId;
    //console.log(insertId);
    
    if (result.status == 1) {
        res.status(200).json({ status: 1, "message": result.message, data: result.data });     
    }
    else {
        res.status(200).json({ status: 0, "message": result.message });

    }
    
    
    
}
module.exports.updateProposerDetails = async (req, res, next) => {
    
    const body = req.body; 
    const portfolioId = body.id;
    const tableName = "proposerdetails";
    delete body.id;
    
    const result = await proposerModel.updateData(body, tableName, portfolioId);
    
    if (result.status == 1) {
        res.status(200).json({ status: 1, "message": result.message, data: result.data });     
    }
    else {
        res.status(200).json({ status: 0, "message": result.message });

    }
}

module.exports.addPolicyCoverage = async (req, res, next) => {
    const body = req.body;
    const tableName = 'policycoverage';
    body.customerId = insertId;
    //console.log(body);
    
    const result = await proposerModel.addProposerDetails(tableName, body)
    console.log(insertId);
    
    if (result.status == 1) {
        res.status(200).json({ status: 1, "message": result.message, data: result.data });     
    }
    else {
        res.status(200).json({ status: 0, "message": result.message });

    }
}
module.exports.updatePolicyCoverage = async (req, res, next) => {
    
    const body = req.body; 
    const portfolioId = body.id;
    const tableName = "policycoverage";
    delete body.id;
    
    const result = await proposerModel.updateData(body, tableName, portfolioId);
    
    if (result.status == 1) {
        res.status(200).json({ status: 1, "message": result.message, data: result.data });     
    }
    else {
        res.status(200).json({ status: 0, "message": result.message });

    }
}


module.exports.addPremiumDetails = async (req, res, next) => {
    const body = req.body;
    const tableName = "premiumdetails"
    body.customerId = insertId;
    //console.log(body);
    
    const result = await proposerModel.addPremiumDetails(tableName, body)
    console.log(insertId);
    
    if (result.status == 1) {
        res.status(200).json({ status: 1, "message": result.message, data: result.data });     
    }
    else {
        res.status(200).json({ status: 0, "message": result.message });

    }
}
module.exports.updatePremiumDetails = async (req, res, next) => {
    
    const body = req.body; 
    const portfolioId = body.id;
    const tableName = "premiumdetails";
    delete body.id;
   
    const result = await proposerModel.updateData(body, tableName, portfolioId);
    
    if (result.status == 1) {
        res.status(200).json({ status: 1, "message": result.message, data: result.data });     
    }
    else {
        res.status(200).json({ status: 0, "message": result.message });

    }
}
module.exports.addBankDetails = async (req, res, next) => {
    const body = req.body;
    const tableName = "bankdetails"
    body.customerId = insertId;
    const result = await proposerModel.addBankDetails(tableName, body)
    
    if (result.status == 1) {
        res.status(200).json({ status: 1, "message": result.message, data: result.data });     
    }
    else {
        res.status(200).json({ status: 0, "message": result.message });

    }
}
module.exports.updateBankDetails = async (req, res, next) => {
    
    const body = req.body; 
    const portfolioId = body.id;
    const tableName ="bankdetails";
    delete body.id;
    
    const result = await proposerModel.updateData(body, tableName, portfolioId);
    
    if (result.status == 1) {
        res.status(200).json({ status: 1, "message": result.message, data: result.data });     
    }
    else {
        res.status(200).json({ status: 0, "message": result.message });

    }
}
module.exports.getCustomerDetails = async (req, res, next) => {
    //res.send("this is the health controller");
    const result = await proposerModel.getCustomerDetails(req.body)

    if (result.status == 1) {
        console.log(result);
        res.status(200).json({ status: 1, "message": 'success', data: result.data });
    }
    else {
        res.status(200).json({ status: 0, "message": result.message });

    }
}

