var userModel = require('../model/users/userModel.js');
const jwt = require('jsonwebtoken');
const { body, validationResult, param,query} = require('express-validator/check');

exports.validate = (method) => {
    switch (method) {
        case 'login': {
            return [
                // body('email').not().isEmpty().withMessage("Email is required").isEmail().withMessage("Please enter a valid email address")
                // .isLength({ max: 50 }).withMessage("Email must be less than 50 characters"),
                body('password', "password is required").trim().escape().not().isEmpty(),
                body('email', "email is required").not().trim().escape().isEmpty()
            ]
        }
        case 'signup': {
            return [
                body('email').trim().escape().not().isEmpty().withMessage("Email is required").isEmail().withMessage("Please enter a valid email address"),
                body('password', "password is required").trim().escape().not().isEmpty(),
                body('otp', "otp is required").not().trim().escape().isEmpty(),
                body('phone', "phone is required").trim().escape().not().isEmpty()           
            ]
        }
        case 'sendOTP': {
            return [               
                body('phone', "phone is required").trim().escape().not().isEmpty(),
                body('email').trim().escape().not().isEmpty().withMessage("Email is required").isEmail()
                .withMessage("Please enter a valid email address"),
              
            ]
        }
        case 'socialLogin': {
            return [               
                body('type', "type is required").trim().escape().not().isEmpty().isInt({ min:1, max: 2 }).withMessage('type must be 1 ( For FB) or 2 (FOR Google)'),
                body('email').trim().escape().not().isEmpty().withMessage("Email is required").isEmail().withMessage("Please enter a valid email address"),
              
                body('socialId', "socialId is required").trim().escape().not().isEmpty()
            ]
        }
        
        case 'updateProfile': {
            return [               
                body('fullName').trim().escape(),
                body('phone').trim().escape()                              
            ]
        }  
        case 'resetPassword': {
            return [          
              body('new_pass','new_pass is required').not().isEmpty()
              .matches(/((?=.*[A-Z])(?=.*\W).{6,6})/).withMessage("New Password should be minimum 6 characters and include a capital letter and a special character"),
              body('confirm_pass').not().isEmpty().withMessage('Confirm Password is required').custom((value, { req }) => {                
                return req.body.new_pass === value ?  true : false
              }).withMessage("New password & Confirm password don't match.")
            ]
        }  
        case 'resetForgotPassword': {
            return [          
              body('new_pass','new_pass is required').not().isEmpty()
              .matches(/((?=.*[A-Z])(?=.*\W).{6,6})/).withMessage("New Password should be minimum 6 characters and include a capital letter and a special character"),
              body('confirm_pass').not().isEmpty().withMessage('Confirm Password is required').custom((value, { req }) => {                
                return req.body.new_pass === value ?  true : false
              }).withMessage("New password & Confirm password don't match.")
            ]
        }      
        case 'changePassword': {
            return [
              body('current_pass','current_pass is required').not().isEmpty(),
              body('new_pass','new_pass is required').not().isEmpty()
            //   .isLength({ min: 6 })
            //   .withMessage("Password must contain at least 6 characters")
              .matches(/((?=.*[A-Z])(?=.*\W).{6,6})/).withMessage("New Password should be minimum 6 characters and include a capital letter and a special character"),
              body('confirm_pass').not().isEmpty().withMessage('confirm_pass is required').custom((value, { req }) => {               
                return req.body.new_pass === value ?  true : false
              }).withMessage("New password & Confirm password don't match.")
            ]
        }
        case 'forgotpass': {
            return [              
              body('email').not().isEmpty().withMessage("Email is required").isEmail().withMessage("Please enter a valid email address")
              .isLength({ max: 50 }).withMessage("Email must be less than 50 characters"),
            ]
        }
        
      
    }
};

const failures = ({ location, msg, parameter, value, nestedErrors }) => {
    return {
        param: parameter,
        message: msg,
        nestedErrors: nestedErrors
    }
};

const signupFailures = ({ location, msg, parameter, value, nestedErrors }) => {
    return {
        param: parameter,
        message: msg,
        nestedErrors: nestedErrors
    }
};


/** method for signin */
module.exports.signIn = async (req, res, next) => {
  
    const errors = validationResult(req).formatWith(signupFailures);
    if (!errors.isEmpty()) {
        res.status(422).json({ errors: errors.array() });
        return;
    }
    const result = await userModel.login(req.body.email, req.body.password)
    if (result.status == 1) {
        res.status(200).json({ status: 1, "message": result.message, data: result.data });        
    }
    else {
        res.status(200).json({ status: 0, "message": result.message });

    }
}

/** method for social Login */
module.exports.socialLogin = async (req, res, next) => {
  
    const errors = validationResult(req).formatWith(signupFailures);
    if (!errors.isEmpty()) {
        res.status(422).json({ errors: errors.array() });
        return;
    }
    const result = await userModel.socialLogin(req.body)
    if (result.status == 1) {
        res.status(200).json({ status: 1, "message": result.message, data: result.data });        
    }
    else {
        res.status(200).json({ status: 0, "message": result.message });

    }
}



/** method for signup */
module.exports.signup = async (req, res, next) => {
 
    const errors = validationResult(req).formatWith(signupFailures);
    if (!errors.isEmpty()) {
        res.status(422).json({ errors: errors.array() });
        return;
    }
    const result = await userModel.signup(req.body)
    
    if (result.status == 1) {
        res.status(200).json({ status: 1, "message": result.message, data: result.data });     
    }
    else {
        res.status(200).json({ status: 0, "message": result.message });

    }
}

/** method for sendOTP */
module.exports.sendOTP = async (req, res, next) => {
 
    const errors = validationResult(req).formatWith(signupFailures);
    if (!errors.isEmpty()) {
        res.status(422).json({ errors: errors.array() });
        return;
    }
    const result = await userModel.sendOTP(req.body)
    
    if (result.status == 1) {
        console.log(result);
        res.status(200).json({ status: 1, "message": 'success', data: result });
    }
    else {
        res.status(200).json({ status: 0, "message": result.message });

    }
}

/* updateProfile */
module.exports.updateProfile  = async (req, res, next) => {
    try{
        const errors = validationResult(req).formatWith(failures);
        if(!errors.isEmpty()) {
            res.status(422).json({ errors: errors.array() });
            return;
        }
    
        const result = await userModel.updateProfile(req.body);       
        if (result.status == 1) {           
            res.status(200).json({ status: 1, "message": result.message, data:result.data });           
        }
        else {
            res.status(200).json({ status: 0, "message": result.message });
        }
    } catch(error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        next(error);
    }
}

/** method for getProfile */
module.exports.getProfile = async (req, res, next) => {
    const errors = validationResult(req).formatWith(signupFailures);
    if (!errors.isEmpty()) {
        res.status(422).json({ errors: errors.array() });
        return;
    }
    const result = await userModel.getProfile(req.body)
    if (result.status == 1) {       
        res.status(200).json({ status: 1, "message": 'success', data:result.data});       
    }
    else {
        res.status(200).json({ status: 0, "message": result.message });

    }
}

/* Reset password */
module.exports.resetPassword  = async (req, res, next) => {
    try{
        const errors = validationResult(req).formatWith(failures);
        if(!errors.isEmpty()) {
            res.status(422).json({ errors: errors.array() });
            return;
        }
        
        const result = await userModel.resetPassword(req.body);       
        if (result.status == 1) {           
            res.status(200).json({ status: 1, "message": result.message });           
        }
        else {
            res.status(200).json({ status: 0, "message": result.message });
        }
    } catch(error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        next(error);
    }
}

/* Reset password */
module.exports.resetForgotPassword  = async (req, res, next) => {
    try{
        const errors = validationResult(req).formatWith(failures);
        if(!errors.isEmpty()) {
            res.status(422).json({ errors: errors.array() });
            return;
        }       
    
        const result = await userModel.resetForgotPassword(req.body);       
        if (result.status == 1) {           
            res.status(200).json({ status: 1, "message": result.message });           
        }
        else {
            res.status(200).json({ status: 0, "message": result.message });
        }
    } catch(error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        next(error);
    }
}

/* Change password */
module.exports.changePassword  = async (req, res, next) => {
    try{
        const errors = validationResult(req).formatWith(failures);
        if(!errors.isEmpty()) {
            res.status(422).json({ errors: errors.array() });
            return;
        }
        
        const result = await userModel.changePassword(req.body);       
        if (result.status == 1) {           
            res.status(200).json({ status: 1, "message": result.message });           
        }
        else {
            res.status(200).json({ status: 0, "message": result.message });
        }
    } catch(error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        next(error);
    }
}

/** forgot password */
module.exports.forgotPassword = async(req, res, next) => {
    const errors = validationResult(req).formatWith(failures);
    if (!errors.isEmpty()) {
        res.status(422).json({ errors: errors.array() });
        return;
    }
    try {
        const result = await userModel.forgotPassword(req.body.email);
        if (result.status == 1) {
            res.status(200).json({ status: 1, message: result.message });
        }
        else {
            res.status(200).json({ status: 0, message: result.message });
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        next(error);
    }
}


/** method for getProfile */
module.exports.getCarMake = async (req, res, next) => {    
    const result = await userModel.getCarMake(req.body)
    if (result.status == 1) {       
        res.status(200).json({ status: 1, "message": 'success', data:result.data});       
    }
    else {
        res.status(200).json({ status: 0, "message": result.message });
    }
}

/** method for getProfile */
module.exports.getCarModel = async (req, res, next) => {    
    const result = await userModel.getCarModel(req.query)
    if (result.status == 1) {       
        res.status(200).json({ status: 1, "message": 'success', data:result.data});       
    }
    else {
        res.status(200).json({ status: 0, "message": result.message });
    }
}

module.exports.getRTO = async (req, res, next) => {    
    const result = await userModel.getRTO(req.query)
    if (result.status == 1) {       
        res.status(200).json({ status: 1, "message": 'success', data:result.data});       
    }
    else {
        res.status(200).json({ status: 0, "message": result.message });
    }
}
module.exports.blockUser = async (req, res, next) => {    
    const result = await userModel.blockUser(req.body)
    if (result.status == 1) {       
        res.status(200).json({ status: 1, "message": 'success', data:result.data});       
    }
    else {
        res.status(200).json({ status: 0, "message": result.message });
    }
}

module.exports.unblockUser = async (req, res, next) => {    
    const result = await userModel.unblockUser(req.body)
    if (result.status == 1) {       
        res.status(200).json({ status: 1, "message": 'success', data:result.data});       
    }
    else {
        res.status(200).json({ status: 0, "message": result.message });
    }
}
