var department = require('../model/department/departmentModel.js');

module.exports.getAllDepartments = async (req, res, next) => {
    const result = await department.getAllDepartment(req.body)

    if (result.status == 1) {
        res.status(200).json({ status: 1, "message": 'success', data: result.data });
    }
    else {
        res.status(200).json({ status: 0, "message": result.message });

    }
}

module.exports.addDepartment = async (req, res, next) => {

    const result = await department.addDepartment(req.body)
    if (result.status == 1) {       
        res.status(200).json({ status: 1, "message": 'success', data:result.data});       
    }
    else {
        res.status(200).json({ status: 0, "message": result.message });
    }
}

module.exports.deleteDepartment = async (req, res, next) => {

    const result = await department.deleteDepartment(req.body)
    if (result.status == 1) {       
        res.status(200).json({ status: 1, "message": 'success', data:result.data});       
    }
    else {
        res.status(200).json({ status: 0, "message": result.message });
    }
}

module.exports.updateDepartment = async (req, res, next) => {

    const result = await department.updateDepartment(req.body)
    if (result.status == 1) {       
        res.status(200).json({ status: 1, "message": 'success', data:result.data});       
    }
    else {
        res.status(200).json({ status: 0, "message": result.message });
    }
}
