var bikeModel = require('../model/bike/bikeModel.js');

/** method for getBikePolicyTypes */
module.exports.getBikePolicyTypes = async (req, res, next) => {
    const result = await bikeModel.getBikePolicyTypes(req.body)
    if (result.status == 1) {
        res.status(200).json({ status: 1, "message": 'success', data: result.data });
    }
    else {
        res.status(200).json({ status: 0, "message": result.message });
    }
}

/** method for getBikeModels */
module.exports.getBikeModels = async (req, res, next) => {
    const result = await bikeModel.getBikeModels(req.body)
    if (result.status == 1) {
        res.status(200).json({ status: 1, "message": 'success', data: result.data });
    }
    else {
        res.status(200).json({ status: 0, "message": result.message });
    }
}

/** method for getBikeMakes */
module.exports.getBikeMakes = async (req, res, next) => {
    const result = await bikeModel.getBikeMakes(req.body)
    if (result.status == 1) {
        res.status(200).json({ status: 1, "message": 'success', data: result.data });
    }
    else {
        res.status(200).json({ status: 0, "message": result.message });
    }
}