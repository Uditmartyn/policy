const termModel = require("../model/term/termLifeModel");

module.exports.getsalaryRange = async (req, res, next) => {
    //res.send("this is the health controller");
    const result = await termModel.getsalaryRange(req.body)

    if (result.status == 1) {
        console.log(result);
        res.status(200).json({ status: 1, "message": 'success', data: result.data });
    }
    else {
        res.status(200).json({ status: 0, "message": result.message });

    }
}
module.exports.getInsuranceCompanies = async (req, res, next) => {
    //res.send("this is the health controller");
    const result = await termModel.getInsuranceCompanies(req.body)

    if (result.status == 1) {
        console.log(result);
        res.status(200).json({ status: 1, "message": 'success', data: result.data });
    }
    else {
        res.status(200).json({ status: 0, "message": result.message });

    }
}
module.exports.addCustomerDetails = async (req, res, next) => {
    const body = req.body;
    const tableName = 'lifeterm_addcustomerdetails';
  
    const result = await termModel.InsertData(tableName, body)

    if (result.status == 1) {
        console.log(result);
        res.status(200).json({ status: 1, "message": 'success', data: result.data });
    }
    else {
        res.status(200).json({ status: 0, "message": result.message });

    }
    }
    

module.exports.getCustomerDetails = async (req, res, next) => {
   const tableName = "lifeterm_addcustomerdetails"
    const result = await termModel.getCustomerDetails(tableName)

    if (result.status == 1) {
        console.log(result);
        res.status(200).json({ status: 1, "message": 'success', data: result.data });
    }
    else {
        res.status(200).json({ status: 0, "message": result.message });

    }
}
module.exports.getSaveForChild = async (req, res, next) => {
    const tableName = "lifeterm_saveforchild"
     const result = await termModel.getCustomerDetails(tableName)
 
     if (result.status == 1) {
         console.log(result);
         res.status(200).json({ status: 1, "message": 'success', data: result.data });
     }
     else {
         res.status(200).json({ status: 0, "message": result.message });
 
     }
 }
 module.exports.getInvestmentTaxplanningCustomerdetails = async (req, res, next) => {
    const tableName = "investment_taxplanning_customerdetails";
     const result = await termModel.getCustomerDetails(tableName)
 
     if (result.status == 1) {
         console.log(result);
         res.status(200).json({ status: 1, "message": 'success', data: result.data });
     }
     else {
         res.status(200).json({ status: 0, "message": result.message });
 
     }
 }
 
 module.exports.getPensionRetireCustomerDetails  = async (req, res, next) => {
    const tableName = "pension_retairement_customerdetails";
     const result = await termModel.getCustomerDetails(tableName)
 
     if (result.status == 1) {
         console.log(result);
         res.status(200).json({ status: 1, "message": 'success', data: result.data });
     }
     else {
         res.status(200).json({ status: 0, "message": result.message });
 
     }
 }