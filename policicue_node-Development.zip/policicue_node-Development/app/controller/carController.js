var carModel = require('../model/car/carModel.js');

/** method for getCarPolicyTypes */
module.exports.getCarPolicyTypes = async (req, res, next) => {
    const result = await carModel.getCarPolicyTypes(req.body)

    if (result.status == 1) {
        console.log(result);
        res.status(200).json({ status: 1, "message": 'success', data: result.data });
    }
    else {
        res.status(200).json({ status: 0, "message": result.message });

    }
}
module.exports.getMakeModelVariant = async (req, res, next) => {
    
        const result = await carModel.getMakeModelVariant(req.body)
        if (result.status == 1) {       
            res.status(200).json({ status: 1, "message": 'success', data:result.data});       
        }
        else {
            res.status(200).json({ status: 0, "message": result.message });
        }
    
}
