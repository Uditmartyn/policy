const travelModel = require("../model/travel/travelModel");

module.exports.getCountriesList = async (req, res, next) => {
    //res.send("this is the health controller");
    const result = await travelModel.getCountriesList(req.body)

    if (result.status == 1) {
        console.log(result);
        res.status(200).json({ status: 1, "message": 'success', data: result.data });
    }
    else {
        res.status(200).json({ status: 0, "message": result.message });

    }
}
