var adminModel = require('../model/admin/adminModel.js');
const jwt = require('jsonwebtoken');
const { body, validationResult , param} = require('express-validator/check');

exports.validate = (method) => {
    
    switch (method) {
        case 'login': {
            return [
                body('email').not().isEmpty().withMessage("email is required").isEmail().withMessage("valid email is required"),
                body('password', "password is required").not().isEmpty()
            ]
        }        
    }
};

const signupFailures = ({ location, msg, parameter, value, nestedErrors }) => {
    return {
        param: parameter,
        message: msg,
        nestedErrors: nestedErrors
    }
};

/** method for signin */
module.exports.signIn = async (req, res, next) => {
  
    const errors = validationResult(req).formatWith(signupFailures);
    if (!errors.isEmpty()) {
        res.status(422).json({ errors: errors.array() });
        return;
    }
    const result = await adminModel.login(req.body.email, req.body.password)
    if (result.loggedin == 1) {
        res.status(200).json({ status: 1, "message": result.message, data: result.data });        
    }
    else {
        res.status(200).json({ status: 0, "message": result.message });

    }
}
