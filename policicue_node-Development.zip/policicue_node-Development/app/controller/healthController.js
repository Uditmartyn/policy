var healthModel = require('../model/health/healthModel');
const  connection  = require('../../db.js');
//const multer = require('multer');

var insertId;

/** method for getCityPincodes */
module.exports.getcityPincode = async (req, res, next) => {
    //res.send("this is the health controller");
    const result = await healthModel.getCityPincodes(req.body)

    if (result.status == 1) {
        console.log(result);
        res.status(200).json({ status: 1, "message": 'success', data: result.data });
    }
    else {
        res.status(200).json({ status: 0, "message": result.message });

    }
}
/** method for getHealthInsurers */
module.exports.getHealthInsurers = async (req, res, next) => {
    //res.send("this is the health controller");
    const result = await healthModel.getHealthInsurers(req.body)

    if (result.status == 1) {
        console.log(result);
        res.status(200).json({ status: 1, "message": 'success', data: result.data });
    }
    else {
        res.status(200).json({ status: 0, "message": result.message });

    }
}
/** method for getCoverAmount  range */
module.exports.getCoverAmount = async (req, res, next) => {
    //res.send("this is the health controller");
    const result = await healthModel.getCoverAmount(req.body)

    if (result.status == 1) {
        console.log(result);
        res.status(200).json({ status: 1, "message": 'success', data: result.data });
    }
    else {
        res.status(200).json({ status: 0, "message": result.message });

    }
}
module.exports.getExistingIllness = async (req, res, next) => {
    //res.send("this is the health controller");
    const result = await healthModel.getExistingIllness(req.body)

    if (result.status == 1) {
        console.log(result);
        res.status(200).json({ status: 1, "message": 'success', data: result.data });
    }
    else {
        res.status(200).json({ status: 0, "message": result.message });

    }
}
/*module.exports.addCustomerDetails = async(req, res, next) => {
   const tableName = "healthcustomertable";
   if(req.body.policiType ==="BuyNewPolicy") {

    const existingDiseasesArray = req.body.existingDiseases;
    const policyHoldersArray = req.body.policyHolders;
    const existingDiseasesString = existingDiseasesArray.join();
    const policyHoldersString = policyHoldersArray.join();
    
    var inputdata = {
        policiType: req.body.policiType,
        policyHolders: policyHoldersString,
        existingDiseases: existingDiseasesString,
        coverAmountInLakh: req.body.coverAmountInLakh,
        phoneNumber: req.body.phoneNumber,
        email: req.body.email,
        policyNumber: null
    }
    
   } else {
    var inputdata = {
        policiType: req.body.policiType,
        policyHolders: null,
        existingDiseases: null,
        coverAmountInLakh: null,
        phoneNumber: null,
        email: null,
        policyNumber: req.body.policyNumber
    }
   }
    
   
    const result = await healthModel.addCustomerDetails(tableName, inputdata);
    
    if (result.status == 1) {
        res.status(200).json({ status: 1, "message": result.message, data: result.data });     
    }
    else {
        res.status(200).json({ status: 0, "message": result.message });

    }
    
    
}*/
/*module.exports.addHealthCustomerDetails_pagebypage= async (req, res, next) => {
    try{
        
        const body = req.body;
        const policyHolders = req.body.policyHolders;
        delete body.policyHolders;*/
       
        /*const policyHolders = [
            {"policyHolder": "self", "dob": "2020-1-1"},
            {"policyHolder": "father", "dob": "2020-1-1"},
            {"policyHolder": "children", "dob": "2020-1-1", "relation": "son"}
        ]*/
        /*if(policyHolders) {
            for (let i = 0; i < policyHolders.length; i++) {
                const element = policyHolders[i];

                element["customerId"] = insertId;
                const policyHoldersResult = await healthModel.addCustomerDetails('health_policyholders', element);
                if (policyHoldersResult.status == 1) {
                    res.status(200).json({ status: 1, "message": policyHoldersResult.message, data: policyHoldersResult.data });     
                }
                else {
                    res.status(200).json({ status: 0, "message": policyHoldersResult.message });
        
                }
        
            }
        }else {
            if(insertId) {
                const updateresult = await healthModel.updateData(body, 'healthcustomertable', insertId);
                if (updateresult.status == 1) {
                    res.status(200).json({ status: 1, "message": updateresult.message, data: updateresult.data });     
                }
                else {
                    res.status(200).json({ status: 0, "message": updateresult.message });
        
                }
            }
            else {
                const result = await healthModel.addCustomerDetails('healthcustomertable', body);
                insertId = result.data.insertId;
                console.log(insertId);
                if (result.status == 1) {
                    res.status(200).json({ status: 1, "message": result.message, data: result.data });     
                }
                else {
                    res.status(200).json({ status: 0, "message": result.message });
        
                }
            }
        }
       
        }
    
      catch(err){
          res.send(err)
      }
    
}*/
module.exports.addHealthCustomerDetails = async(req, res, next) => {
    const body = req.body;
    const policyHolders = req.body.policyHolders;
    const tableName = 'healthcustomertable';
    delete body.policyHolders;
    const result = await healthModel.addCustomerDetails(tableName, body);
    insertId = result.data.insertId;
    
    if (result.status == 1) {
        if(policyHolders) {
            try{
                for (let i = 0; i < policyHolders.length; i++) {
                    const element = policyHolders[i];
                
                    element["customerId"] = insertId;
                    console.log(element);
                    await healthModel.addCustomerDetails('health_policyholders', element);
                }
                res.status(200).json({ status: 1, "message": result.message, data: result.data }); 
           } catch(error) {
            res.status(200).json({ status: 0, "message": error });
           } 
        }    
    }
    else {
        res.status(200).json({ status: 0, "message": result.message });

    }
    
    
    
}
     
